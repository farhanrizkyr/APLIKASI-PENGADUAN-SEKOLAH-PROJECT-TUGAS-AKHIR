@extends('master.tampilan')
@section('title','List Laporan')
@section('content1','List Laporan Pengaduan')
@section('content')
<div class="container">
   @if(Session::get('pesan'))
  <div class="alert alert-success" role="alert"> 
    {{Session::get('pesan')}}
</div>
@endif
<br><br>
  <div class="card" style="padding:11px;">
    <table id="myTable"  class="table">
    	<thead>
    		<tr>
    			<th>No.</th>
    			<th>Laporan</th>
    			<th>Gambar</th>
          <th>Status</th>
    			<th>Descripsi</th>
    			<th>Komentar</th>
    			<th>Aksi</th>
    		</tr>
    	</thead>
    	<?php $no=1; ?>
    	@foreach($pengaduan as $datas)
    	<tbody>
    		<tr>
    			<td>{{$no++;}}</td>
    			<td>{{$datas->name}}</td>
    			<td><img src="{{url('Foto_Pengaduan',$datas->gambar)}}" width="20%;"></td>
          <td>
            @if($datas->status=='Belum DiProsess')
             <i class="fas fa-circle text-danger"></i>  <p>{{$datas->status}}</p>
            @endif
         

             @if($datas->status=='DiProsess')
          <i class="fas fa-circle text-warning"></i>  <p>{{$datas->status}}</p>
            @endif
          </td>
    			<td>{{$datas->penjelasan}}</td>
          <td>{{$datas->balasan}}</td>
          <td>
            <form method="post" action="/siswa/pengaduan-siswa/hapus/{{$datas->id}}" class="d-inline">
              @method('delete')
              @csrf
              <button onclick="return confirm('Yakin Ingin Menghapus?')" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i> Delete</button>
            </form>
          </td>
    		</tr>
    	</tbody>
    	@endforeach
    </table>
  </div>
</div>
@endsection
