<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Pengaduan;
use App\Models\User;
use Auth;
use Illuminate\Support\Facades\DB;
class DashboardController extends Controller
{
    function __construct()
   {
      $this->middleware('auth');
   }
   public function index()
   {
       $belum=Pengaduan::where('user_id',auth::user()->id)->wherein('status',['Belum DiProsess'])->orderby('created_at','desc')->count();
       $proses=Pengaduan::where('user_id',auth::user()->id)->wherein('status',['DiProsess'])->orderby('created_at','desc')->count();
       $done=Pengaduan::where('user_id',auth::user()->id)->wherein('status',['done'])->orderby('created_at','desc')->count();
       $users=DB::table('users')->count();
        $belum_d=Pengaduan::where('status','Belum DiProsess')->count();
      $prosess_d=Pengaduan::where('status','DiProsess')->count();
       $total=Pengaduan::where('status','done')->count();;
      return view('Dashboard/index',compact('belum','proses','done','users','belum_d','prosess_d','total'));
   }
}
