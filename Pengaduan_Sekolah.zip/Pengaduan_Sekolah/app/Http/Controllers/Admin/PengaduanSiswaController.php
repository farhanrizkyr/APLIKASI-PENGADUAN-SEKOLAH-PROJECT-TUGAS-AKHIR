<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Pengaduan;
use Auth;
class PengaduanSiswaController extends Controller
{

     function __construct($foo = null)
   {
      $this->middleware('auth');
      $this->middleware('admin');
   }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         $pengaduan=Pengaduan::wherein('status',['Belum DiProsess','DiProsess'])->orderby('created_at','desc')->get();
       return view('List_Pengaduan_Siswa/index',compact('pengaduan'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       $tanggapan=Pengaduan::find($id);
       return view('List_Pengaduan_Siswa/tanggapan',compact('tanggapan'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update( $id)
    {
       request()->validate([
        'balasan'=>'required'


       ]);

       Pengaduan::find($id)->update([
       'balasan'=>request()->balasan,
        'status'=>request()->status,

       ]);

       return redirect('/pengaduan-siswa/')->with('pesan','Pengaduan Telah Di Tanggapi');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function history()
    {
         $pengaduan=Pengaduan::where('status','done')->orderby('created_at','desc')->get();
       return view('List_Pengaduan_Siswa/rekap',compact('pengaduan'));
    }
}
