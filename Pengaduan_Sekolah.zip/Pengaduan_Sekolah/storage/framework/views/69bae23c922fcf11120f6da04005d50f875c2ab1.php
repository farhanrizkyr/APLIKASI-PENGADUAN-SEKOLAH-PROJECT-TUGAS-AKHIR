
<?php $__env->startSection('title','List Laporan Siswa'); ?>
<?php $__env->startSection('content1','List Laporan Pengaduan Siswa'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
   <?php if(Session::get('pesan')): ?>
  <div class="alert alert-success" role="alert"> 
    <?php echo e(Session::get('pesan')); ?>

</div>
<?php endif; ?>
<br><br>
  <div class="card" style="padding:11px;">
    <table id="myTable"  class="table">
    	<thead>
    		<tr>
    			<th>No.</th>
    			<th>Laporan</th>
    			<th>Gambar</th>
          <th>Status</th>
    			<th>Descripsi</th>
    			<th>Komentar</th>
    			<th>Aksi</th>
    		</tr>
    	</thead>
    	<?php $no=1; ?>
    	<?php $__currentLoopData = $pengaduan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    	<tbody>
    		<tr>
    			<td><?php echo e($no++); ?></td>
    			<td><?php echo e($datas->name); ?></td>
    			<td><img src="<?php echo e(url('Foto_Pengaduan',$datas->gambar)); ?>" width="20%;"></td>
          <td>
            <?php if($datas->status=='Belum DiProsess'): ?>
             <i class="fas fa-circle text-danger"></i>  <p><?php echo e($datas->status); ?></p>
            <?php endif; ?>
         

             <?php if($datas->status=='DiProsess'): ?>
          <i class="fas fa-circle text-warning"></i>  <p><?php echo e($datas->status); ?></p>
            <?php endif; ?>
          </td>
    			<td><?php echo e($datas->penjelasan); ?></td>
          <td>
          	
          	<?php echo e($datas->balasan); ?>

          </td>
          <td>
            <a href="/pengaduan-siswa/tanggapi/<?php echo e($datas->id); ?>" class="btn btn-warning btn-sm"><i class="fas fa-comment"></i> Tanggapi Pengaduan</a>
          </td>
    		</tr>
    	</tbody>
    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.tampilan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Pengaduan_Sekolah\resources\views/List_Pengaduan_Siswa/index.blade.php ENDPATH**/ ?>