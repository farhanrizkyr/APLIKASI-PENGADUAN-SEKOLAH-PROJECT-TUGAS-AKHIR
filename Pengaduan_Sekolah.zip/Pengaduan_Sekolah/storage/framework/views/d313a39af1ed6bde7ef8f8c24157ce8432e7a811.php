
<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content1','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<!-- Admin-->
<?php if(Auth::user()->role=='admin'): ?>
<div class="card" style="padding:22px;">
	<div class="container">
		<div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
              <div class="card card-statistic-1">
                <div class="card-icon bg-primary">
                  <i class="far fa-user"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Total User</h4>
                  </div>
                  <div class="card-body">
                    <?php echo e($users); ?>

                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
              <div class="card card-statistic-1">
                <div class="card-icon bg-danger">
                  <i class="far fa-file"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Total Pandding</h4>
                  </div>
                  <div class="card-body">
                  <?php echo e($belum_d); ?>

                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
              <div class="card card-statistic-1">
                <div class="card-icon bg-warning">
                  <i class="far fa-file"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Total Prosess</h4>
                  </div>
                  <div class="card-body">
                    <?php echo e($prosess_d); ?>

                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
              <div class="card card-statistic-1">
                <div class="card-icon bg-success">
                  <i class="fas fa-clipboard-check"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Total Sudah DiTanggapi</h4>
                  </div>
                  <div class="card-body">
                  <?php echo e($total); ?>

                  </div>
                </div>
              </div>
            </div>                  
          </div>
	</div>
</div>

<?php endif; ?>
<!-- End Admin-->
<!--  Siswa-->
<?php if(Auth::user()->role=='siswa'): ?>
<div class="card" style="padding:22px;">
	<div class="container">
		<div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
              <div class="card card-statistic-1">
                <div class="card-icon bg-primary">
                <i class="fas fa-clipboard-check"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Jumlah Laporan</h4>
                  </div>
                  <div class="card-body">
                   <?php echo e(Auth::user()->users->count()); ?>

                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
              <div class="card card-statistic-1">
                <div class="card-icon bg-danger">
                 <i class="fas fa-exclamation-triangle"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Panding</h4>
                  </div>
                  <div class="card-body">
                 <?php echo e($belum); ?>

                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
              <div class="card card-statistic-1">
                <div class="card-icon bg-warning">
               <i class="fas fa-sync"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Prosess</h4>
                  </div>
                  <div class="card-body">
                   <?php echo e($proses); ?>

                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
              <div class="card card-statistic-1">
                <div class="card-icon bg-success">
                  <i class="fas fa-check"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Selesai</h4>
                  </div>
                  <div class="card-body">
                   <?php echo e($done); ?>

                  </div>
                </div>
              </div>
            </div>                  
          </div>
	</div>
</div>

<?php endif; ?>
<!-- End Siswa-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.tampilan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Pengaduan_Sekolah\resources\views/Dashboard/index.blade.php ENDPATH**/ ?>