@extends('master.tampilan')
@section('title','Buat Laporan')
@section('content1','Laporan Pengaduan')
@section('content')
<div class="container">
  @if(Session::get('pesan'))
  <div class="alert alert-success" role="alert"> 
    {{Session::get('pesan')}}
    <br>
    Silahkan  <a href="/siswa/pengaduan-siswa/">Klik</a> Untuk Ke Menu List Laporan Pengaduan
</div>
@endif
<br><br>
  <div class="card" style="padding:11px;">
    <form method="POST" action="" enctype="multipart/form-data">
      @csrf
      <div class="grup">
        <label>Laporan Pengaduan</label>
        <input type="text" name="name" class="form-control @error('name')is-invalid @enderror" autocomplete="off" value="{{old('name')}}">
        @error('name')
        <p class="text-danger">{{$message}}</p>
        @enderror
      </div>

      <div class="grup">
        <label>Gambar</label>
        <input type="file" name="gambar" class="form-control @error('gambar')is-invalid @enderror" autocomplete="off" >
        @error('gambar')
        <p class="text-danger">{{$message}}</p>
        @enderror
      </div>

      <div class="grup">
        <label>Deskripsi</label>
       <textarea class="form-control @error('penjelasan')is-invalid @enderror" rows="11" cols="10" name="penjelasan">{{old('penjelasan')}}</textarea>
          @error('penjelasan')
        <p class="text-danger">{{$message}}</p>
        @enderror
      </div>

      <button class="btn btn-primary mt-3"><i class="fas fa-save"></i>  Buat Pengaduan</button>
    </form>
  </div>
</div>
@endsection
