<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Hash;
class UserController extends Controller
{
   function __construct($foo = null)
   {
      $this->middleware('auth');
      $this->middleware('admin');
   }
   public function index()
   {
      $users=User::orderby('created_at','desc')->get();
       return view('Dashboard/account',compact('users'));
   }

   public function create($value='')
   {
    request()->validate([
      'name'=>'required',
      'password'=>'required|confirmed',
      'email'=>'required|unique:users|email:dns',
      'username'=>'required|unique:users',
     ]);

    User::create([
    'name'=>request()->name,
    'username'=>request()->username,
    'email'=>request()->email,
    'role'=>request()->role,
    'password'=>hash::make(request()->password),
    ]);
    return redirect('/account/')->with('pesan','User Baru Berhasil DiBuat');
   }

   public function destroy($id)
   {
      $user=User::find($id);
      $user->delete();
      return redirect('/account/')->with('pesan','User Baru Berhasil Dihapus');
   }
}
