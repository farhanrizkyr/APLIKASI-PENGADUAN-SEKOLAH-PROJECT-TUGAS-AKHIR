@extends('master.tampilan')
@section('title','Tanggapi Laporan')
@section('content1','Tanggapi Laporan Pengaduan Siswa')
@section('content')
<div class="container">
 <div class="card" style="padding:22px;">
 <form method="post" action="/pengaduan-siswa/proses_tanggapan/{{$tanggapan->id}}">
 	@csrf
 	<div class="grup">
 		<label>Nama Siswa</label>
 		<input type="text" name="user_id" value="{{$tanggapan->user->name}}" readonly class="form-control">
 	</div>


 		<div class="grup">
 		<label>Laporan Siswa</label>
 		<input type="text" name="name" value="{{$tanggapan->name}}" readonly class="form-control">
 	</div>
 	<br><br>
 		<div class="grup">
 		<label>Bukti Foto</label>
 		<img src="{{url('Foto_Pengaduan',$tanggapan->gambar)}}" width="30%;">
 	</div>
<br><br>

 	 	<div class="grup">
 		<label>Status </label>
 		<select name="status" class="form-control">
 			<option value="Belum DiProsess" @if($tanggapan->status=='Belum DiProsess') selected @endif>Belum DiProses</option>
 			<option value="DiProsess" @if($tanggapan->status=='DiProsess')selected   @endif>DiProses</option>
 			<option value="done"  @if($tanggapan->status=='done')selected @endif>Selesai</option>
 		</select>
 		
 	</div>


	<div class="grup">
 		<label>Descripsi Laporan</label>
 		<textarea class="form-control" cols="12" readonly rows="10">{{$tanggapan->penjelasan}}</textarea>
 	</div>


	<div class="grup">
 		<label>Tanggapi Laporan</label>
 		<textarea class="form-control" cols="12" name="balasan"  rows="10">{{$tanggapan->balasan}}</textarea>
 		@error('balasan')
 		<p class="text-danger">{{$message}}</p>
 		@enderror
 	</div>

  <div class="mt-3">
  	<button class="btn btn-primary"><i class="fas fa-save"></i> Tanggapi</button>
  	<a href="/pengaduan-siswa" class="btn btn-warning"><i class="fas fa-arrow-left"></i> Kembali</a>
  </div>


 </form>
 </div>
</div>
@endsection
