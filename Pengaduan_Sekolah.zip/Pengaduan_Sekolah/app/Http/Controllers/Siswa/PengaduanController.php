<?php

namespace App\Http\Controllers\Siswa;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Pengaduan;
use Auth;
class PengaduanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    function __construct($foo = null)
    {
        $this->middleware('auth');
         $this->middleware('siswa');
    }
    public function index()
    {
      return view('Siswa/laporan');
    }

     public function list()
    {

      $pengaduan=Pengaduan::where('user_id',auth::user()->id)->wherein('status',['Belum DiProsess','DiProsess'])->orderby('created_at','desc')->get();
      return view('Siswa/list_laporan',compact('pengaduan'));
    }
   public function list_history()
    {

      $pengaduan=Pengaduan::where('user_id',auth::user()->id)->wherein('status',['done'])->orderby('created_at','desc')->get();
      return view('Siswa/list_history',compact('pengaduan'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       request()->validate([
         'name'=>'required',
         'gambar'=>'required|mimes:jpg,png,jpeg|max:2048',
         'penjelasan'=>'required',

        ],
        [
         'name.required'=>'Wajib DiIsi',
         'gambar.required'=>'Wajib DiIsi',
         'gambar.mimes'=>'Gambar Wajib JPG,PNG,JPEG',
         'gambar.max'=>'Ukuran Gambar Tidak Boleh Lebih Dari 2MB',
         'penjelasan.required'=>'Wajib DiIsi',

        ]);

        $file=request()->file('gambar');
        $filename=$file->getClientOriginalName();
        $file->move(public_path('Foto_Pengaduan'),$filename);

  

        Pengaduan::create([
        'name'=>request()->name,
         'user_id'=>Auth::user()->id,
        'penjelasan'=>request()->penjelasan,
        'gambar'=>$filename,
        ]);
        return redirect('/buat-laporan')->with('pesan','Pengaduan Berhasil DiBuat');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
      $data=Pengaduan::find($id);
      if ($data->gambar <> '') {
        unlink(public_path('Foto_Pengaduan').'/'.$data->gambar);
      }
      $data->delete();
        return redirect('/siswa/pengaduan-siswa/')->with('pesan','Pengaduan Berhasil DiHapus');
    }

    public function history($id)
    {
      $data=Pengaduan::find($id);
      if ($data->gambar <> '') {
        unlink(public_path('Foto_Pengaduan').'/'.$data->gambar);
      }
      $data->delete();
        return redirect('/history/siswa/pengaduan-siswa/')->with('pesan','Pengaduan Berhasil DiHapus');
    }
}
