@extends('master.tampilan')
@section('title','List Laporan Siswa')
@section('content1','List Laporan Pengaduan Siswa')
@section('content')
<div class="container">
   @if(Session::get('pesan'))
  <div class="alert alert-success" role="alert"> 
    {{Session::get('pesan')}}
</div>
@endif
<br><br>
  <div class="card" style="padding:11px;">
    <table id="myTable"  class="table">
    	<thead>
    		<tr>
    			<th>No.</th>
    			<th>Laporan</th>
    			<th>Gambar</th>
          <th>Status</th>
    			<th>Descripsi</th>
    			<th>Komentar</th>
  
    		</tr>
    	</thead>
    	<?php $no=1; ?>
    	@foreach($pengaduan as $datas)
    	<tbody>
    		<tr>
    			<td>{{$no++;}}</td>
    			<td>{{$datas->name}}</td>
    			<td><img src="{{url('Foto_Pengaduan',$datas->gambar)}}" width="20%;"></td>
          <td>
            @if($datas->status=='done')
             <i class="fas fa-circle text-success"></i>  <p>Selesai</p>
            @endif
         

          </td>
    			<td>{{$datas->penjelasan}}</td>
          <td>
          	
          	{{$datas->balasan}}
          </td>
          
    		</tr>
    	</tbody>
    	@endforeach
    </table>
  </div>
</div>
@endsection
