<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\User\LoginController;
use App\Http\Controllers\Siswa\PengaduanController;
use App\Http\Controllers\Admin\PengaduanSiswaController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::get('/dashboard',[DashboardController::class,'index']);
//=====================Dashboard============================//
Route::get('/account/',[UserController::class,'index']);
Route::post('/account/',[UserController::class,'create']);
Route::delete('/account/delete/{id}',[UserController::class,'destroy']);
//=====================Siswa_Lap============================//
Route::get('/pengaduan-siswa/',[PengaduanSiswaController::class,'index']);
Route::get('/rekap-pengaduan-siswa/',[PengaduanSiswaController::class,'history']);
Route::get('/pengaduan-siswa/tanggapi/{id}',[PengaduanSiswaController::class,'edit']);
Route::post('/pengaduan-siswa/proses_tanggapan/{id}',[PengaduanSiswaController::class,'update']);
//=====================User============================//
Route::get('/login',[LoginController::class,'login'])->name('login');
Route::get('/logout',[LoginController::class,'logout']);
Route::post('/login',[LoginController::class,'post_login'])->name('post_login');
//=====================Siswa============================//
Route::get('/buat-laporan',[PengaduanController::class,'index']);
Route::post('/buat-laporan',[PengaduanController::class,'create']);
Route::get('/siswa/pengaduan-siswa/',[PengaduanController::class,'list']);
Route::get('/history/siswa/pengaduan-siswa/',[PengaduanController::class,'list_history']);
Route::delete('/siswa/pengaduan-siswa/hapus/{id}',[PengaduanController::class,'destroy']);
Route::delete('/history/siswa/pengaduan-siswa/hapus_history/{id}',[PengaduanController::class,'history']);
