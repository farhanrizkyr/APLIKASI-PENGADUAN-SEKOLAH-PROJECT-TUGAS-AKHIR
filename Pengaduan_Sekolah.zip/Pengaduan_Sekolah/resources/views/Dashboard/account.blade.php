@extends('master.tampilan')
@section('title','Buat User Baru')
@section('content1','Buat User Baru')
@section('content')
@if(Session::get('pesan'))
<div class="alert alert-success" role="alert">
 {{Session::get('pesan')}}
</div>
@endif
<br><br>
<div class="card" style="padding:22px;">
	<div class="container">
		<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  <i class="fas fa-plus"></i> Tambah User Baru
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <br><br>
      <div class="modal-body">
       <form method="post" action="">
         @csrf
         <div class="grup">
           <label>Nama</label>
           <input type="text" name="name" class="form-control @error('name')is-invalid @enderror" autocomplete="off">
           @error('name')
            <p class="text-danger">{{$message}}</p>
           @enderror
         </div>
             <div class="grup">
           <label>Role</label>
            <select name="role" class="form-control">
              <option value="admin">Admin</option>
               <option value="siswa">Siswa</option>
            </select>
         </div>
          <div class="grup">
           <label>Username</label>
           <input type="text" name="username" class="form-control @error('username')is-invalid @enderror" autocomplete="off">
           @error('username')
            <p class="text-danger">{{$message}}</p>
           @enderror
         </div>
          <div class="grup">
           <label>E-Mail</label>
           <input type="text" name="email" class="form-control @error('email')is-invalid @enderror" autocomplete="off">
           @error('email')
            <p class="text-danger">{{$message}}</p>
           @enderror
         </div>

          <div class="grup">
           <label>Password</label>
           <input type="password" name="password" class="form-control @error('password')is-invalid @enderror" autocomplete="off">
           @error('password')
            <p class="text-danger">{{$message}}</p>
           @enderror
         </div>

          <div class="grup">
           <label>Konfirmasi Password</label>
           <input type="password" name="password_confirmation" class="form-control @error('password_confirmation')is-invalid @enderror" autocomplete="off">
           @error('password_confirmation')
            <p class="text-danger">{{$message}}</p>
           @enderror
         </div>
      
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save changes</button>
      </div>
       </form>
    </div>
  </div>
</div>
	</div>
<br><br>
  <table id="myTable" class="table display mb-5">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Username</th>
            <th>Role</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
      <?php $loops=1; ?>
      @foreach($users as $user)
      <tr>
        <th>{{$loops++;}}.</th>
        <th>{{$user->name}}</th>
        <th>{{$user->username}}</th>
        <th>
          @if($user->role=='admin')
            <span class="badge badge-primary">Admin</span>
          @endif
             @if($user->role=='siswa')
            <span class="badge badge-warning">Siswa</span>
       @endif
        </th>
        <th>
          <form method="post" action="/account/delete/{{$user->id}}" class="d-inline">
            @csrf
            @method('delete')
            <button onclick="return confirm('Yakin Ingin Menghapus?')" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i> Delete</button>
          </form>
        </th>
      </tr>


      @endforeach
    </tbody>
</table>
</div>



@endsection