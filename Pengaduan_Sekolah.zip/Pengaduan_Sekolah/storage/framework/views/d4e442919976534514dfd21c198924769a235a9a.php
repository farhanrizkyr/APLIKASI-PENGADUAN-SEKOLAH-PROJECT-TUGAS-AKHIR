
<?php $__env->startSection('title','Tanggapi Laporan'); ?>
<?php $__env->startSection('content1','Tanggapi Laporan Pengaduan Siswa'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
 <div class="card" style="padding:22px;">
 <form method="post" action="/pengaduan-siswa/proses_tanggapan/<?php echo e($tanggapan->id); ?>">
 	<?php echo csrf_field(); ?>
 	<div class="grup">
 		<label>Nama Siswa</label>
 		<input type="text" name="user_id" value="<?php echo e($tanggapan->user->name); ?>" readonly class="form-control">
 	</div>


 		<div class="grup">
 		<label>Laporan Siswa</label>
 		<input type="text" name="name" value="<?php echo e($tanggapan->name); ?>" readonly class="form-control">
 	</div>
 	<br><br>
 		<div class="grup">
 		<label>Bukti Foto</label>
 		<img src="<?php echo e(url('Foto_Pengaduan',$tanggapan->gambar)); ?>" width="30%;">
 	</div>
<br><br>

 	 	<div class="grup">
 		<label>Status </label>
 		<select name="status" class="form-control">
 			<option value="Belum DiProsess" <?php if($tanggapan->status=='Belum DiProsess'): ?> selected <?php endif; ?>>Belum DiProses</option>
 			<option value="DiProsess" <?php if($tanggapan->status=='DiProsess'): ?>selected   <?php endif; ?>>DiProses</option>
 			<option value="done"  <?php if($tanggapan->status=='done'): ?>selected <?php endif; ?>>Selesai</option>
 		</select>
 		
 	</div>


	<div class="grup">
 		<label>Descripsi Laporan</label>
 		<textarea class="form-control" cols="12" readonly rows="10"><?php echo e($tanggapan->penjelasan); ?></textarea>
 	</div>


	<div class="grup">
 		<label>Tanggapi Laporan</label>
 		<textarea class="form-control" cols="12" name="balasan"  rows="10"><?php echo e($tanggapan->balasan); ?></textarea>
 		<?php $__errorArgs = ['balasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
 		<p class="text-danger"><?php echo e($message); ?></p>
 		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
 	</div>

  <div class="mt-3">
  	<button class="btn btn-primary"><i class="fas fa-save"></i> Tanggapi</button>
  	<a href="/pengaduan-siswa" class="btn btn-warning"><i class="fas fa-arrow-left"></i> Kembali</a>
  </div>


 </form>
 </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.tampilan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Pengaduan_Sekolah\resources\views/List_Pengaduan_Siswa/tanggapan.blade.php ENDPATH**/ ?>