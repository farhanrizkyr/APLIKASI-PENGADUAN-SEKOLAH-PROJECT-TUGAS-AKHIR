     <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <div class="sidebar-brand">
            <a href="/dashboard">pengaduan Sekolah</a>
          </div>
          <div class="sidebar-brand sidebar-brand-sm">
            <a href="/dashboard">Ps</a>
          </div>

            <!--  Admin-->
            <?php if(Auth::user()->role=='admin'): ?>
          <ul class="sidebar-menu">
         
                       <li><a class="nav-link" href="/dashboard"><i class="fas fa-fire"></i> <span>Dashboard</span></a></li>

                          <li class="menu-header">Menu Admin</li>
            <li class="dropdown active">
              <a href="#" class="nav-link has-dropdown"><i class="fas fa-book"></i><span>Pengaduan</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="/account/">Buat Akun</a></li>
                <li><a class="nav-link" href="/pengaduan-siswa/"> Pengaduan Siswa</a></li>
                <li><a class="nav-link" href="/rekap-pengaduan-siswa/">History Pengaduan Siswa</a></li>
               

              </ul>
            </li>
          </ul>
          <?php endif; ?>
          <!-- End Admin-->

              <!--  Siswa-->
            <?php if(Auth::user()->role=='siswa'): ?>
          <ul class="sidebar-menu">
         
                       <li><a class="nav-link" href="/dashboard"><i class="fas fa-fire"></i> <span>Dashboard</span></a></li>

                          <li class="menu-header">Menu Siswa</li>
            <li class="dropdown active">
              <a href="#" class="nav-link has-dropdown"><i class="fas fa-book"></i><span>Pengaduan</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="/buat-laporan/">Buat Laporan</a></li>
                <li><a class="nav-link" href="/siswa/pengaduan-siswa/"> List Pengaduan Siswa</a></li>
                <li><a class="nav-link" href="/history/siswa/pengaduan-siswa/">History Pengaduan Siswa</a></li>
               

              </ul>
            </li>
          </ul>
          <?php endif; ?>
          <!-- End Admin-->
       
               
      </aside>
      </div><?php /**PATH D:\Pengaduan_Sekolah\resources\views/master/nav.blade.php ENDPATH**/ ?>